//
//  AppDelegate.swift
//  Hello Linkedin 
//
//  Created by Владимир Бессонов on 17.03.17.
//  Copyright © 2017 Владимир Бессонов. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {
    @IBOutlet weak var button1: NSButton!
    @IBOutlet weak var label1: NSTextField!

    @IBOutlet weak var window: NSWindow!


    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
        
        
        label1.stringValue = "Hello Linkedin"
        button1.title = "Change Text"
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }

    @IBAction func changeText(_ sender: Any) {
    
    
    label1.stringValue = "Hello Linkedin! Text Changed"
    
    
    }
    
    
    

}

